import * as en from './en.json'
import * as fr from './fr.json'

export default {
  en,
  fr,
  'fr-US': fr,
}
