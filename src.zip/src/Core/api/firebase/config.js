import { firebase } from '@react-native-firebase/firestore'

export { firebase }
