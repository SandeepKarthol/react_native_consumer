const IMNotificationActionsConstants = {
  SET_NOTIFICATIONS: 'SET_NOTIFICATIONS',
  DID_SUBSCRIBE: 'DID_SUBSCRIBE_TO_NOTIFICATIONS',
}

export default IMNotificationActionsConstants
