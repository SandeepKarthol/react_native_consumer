const dummyPhoneNumber = 22323232323

const mockData = {
  id: '113311313',
  userID: '113311313',
  stripeCustomerID: 'addddvvd',
  phone: dummyPhoneNumber,
  email: 'jane@doe.com',
  firstName: 'Jane',
  lastName: 'Doe',
  profilePictureURL:
    'https://static2.thethingsimages.com/wordpress/wp-content/uploads/2020/05/15-Sickest-Concept-Cars-In-2020-1.jpg',
}

export { mockData }
