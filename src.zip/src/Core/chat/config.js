const callID = 'E621E1F8-C36C-495A-93FC-0C247A3E6E5F'


const pushKitEndpoint =
  'https://us-central1-production-a9404.cloudfunctions.net/initiateChatCall'
const iOSBundleID = 'io.instamobile.chat.rn.ios'

export { callID, pushKitEndpoint, iOSBundleID }
