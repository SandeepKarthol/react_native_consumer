export { default } from './TNEmptyStateView'
